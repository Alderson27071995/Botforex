import asyncio
import datetime
import httpx
import logging
import numpy as np
from aiogram import Bot, Dispatcher
from ta.trend import ADXIndicator

# Configuración de logging
logging.basicConfig(level=logging.INFO)

# Tu token y chat ID
API_TOKEN = "7395640845:AAErS5iqWhQdx_fgi8lPn-blpgPGH-in4QM"
CHAT_ID = "8050249187"

# Configuración de horarios operativos (hora Colombia)
HORA_INICIO = 2  # 2:00 a.m.
HORA_FIN = 15    # 3:00 p.m.

# Pares de divisas y temporalidades que analizará el bot
PARES = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CHF", "NZD/USD", "USD/CAD"]
INTERVALOS = ["1min", "5min", "1h", "1day", "1month"]

# Clave API de Twelve Data
API_KEY = "327b305303ff422092db5171bd77eaee"
# Continuación del bot: procesamiento de señales
def analizar_datos(df, par, intervalo):
    signals = []
    if df is None or len(df) < 50:
        logging.error(f"No hay suficientes datos para {par} en {intervalo}.")
        return signals
    
    df['ADX'] = ta.ADX(df['high'], df['low'], df['close'], timeperiod=14)
    df['RSI'] = ta.RSI(df['close'], timeperiod=14)
    df['SMA'] = ta.SMA(df['close'], timeperiod=14)
    last = df.iloc[-1]

    if last['ADX'] > 25 and last['RSI'] > 50 and last['close'] > last['SMA']:
        signals.append('BUY')
    elif last['ADX'] > 25 and last['RSI'] < 50 and last['close'] < last['SMA']:
        signals.append('SELL')

    return signals

async def enviar_senal(senal, par, intervalo):
    duracion = {
        '1min': '1-5 minutos',
        '5min': '5-15 minutos',
        '1h': '30-60 minutos',
        '1day': '1-2 días',
        '1month': '1-2 meses'
    }.get(intervalo, 'Desconocido')

    mensaje = (
        f"📊 Señal detectada:\n"
        f"🔹 Par: {par}\n"
        f"⏱ Intervalo: {intervalo}\n"
        f"🚦 Operación: {senal}\n"
        f"⏳ Tiempo recomendado: {duracion}"
    )

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {'chat_id': TELEGRAM_CHAT_ID, 'text': mensaje}
    async with httpx.AsyncClient() as client:
        response = await client.post(url, data=payload)
        if response.status_code == 200:
            logging.info(f"✅ Señal enviada para {par} en {intervalo}")
        else:
            logging.error(f"❌ Error enviando señal: {response.text}")
async def main():
    now = datetime.datetime.now()
    if 2 <= now.hour < 15:
        logging.info(f"🟢 Dentro del horario operativo. Generando señales...")

        pares = [
            ('EUR/USD', ['1min', '5min', '1h', '1day', '1month']),
            ('GBP/USD', ['1min', '5min', '1h', '1day', '1month']),
            ('USD/JPY', ['1min', '5min', '1h', '1day', '1month'])
        ]

        for par, intervalos in pares:
            for intervalo in intervalos:
                df = await obtener_datos(par, intervalo)
                if df is not None:
                    senales = analizar_datos(df, par, intervalo)
                    for senal in senales:
                        await enviar_senal(senal, par, intervalo)
                await asyncio.sleep(2)  # evita exceder el límite de API
    else:
        logging.info("🔴 Fuera del horario operativo. El bot esperará el horario adecuado.")

if __name__ == '__main__':
    asyncio.run(main())